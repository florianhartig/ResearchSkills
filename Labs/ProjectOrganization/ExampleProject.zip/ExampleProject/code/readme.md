Complete code to create the results of your project here. Can have subfolders

* Read lab / lecture about reproducibility 
* Read lab / lecture about good coding practice


== Special Comments for R projects or other script-based analysis ==


Suggestion: one graphic or output --> 1 R file (ideally)

Example

helpfunctions1.r
helpfunctions2.r

experiment1.r  -> call helper, write results to folder results
experiment2.r

fig1.r         -> call helper, read results, write output / figure to folder results
fig2.r