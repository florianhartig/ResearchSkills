
# Use relative file paths as in ../data/mydata.Rdata to keep your project portable

