Put the text of your thesis here (word, open office, LaTeX)

I recommend working in Latex --> See lab about LaTeX