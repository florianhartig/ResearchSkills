Put your reference manager database, and pds that you read here

--> See lab about reference manager, this is essential!!!!

Recommendation: use JabRef, which links nicely to LaTeX and can also automatically link the pdfs for each reference