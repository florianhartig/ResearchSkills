For experimental work, it is required that you have a lab notebook in which you record what you are doing each day --> See lecture good scientific practice

NOTE: this is an official document, it is EXTREMELY CRUCIAL that you have a properly organized lab notebook. Check the rules of your lab. Often, the notebook MUST be on paper. In this case, I would place a scan in this folder.

For software-based work, the version control system should do a lot of this work already if you use it properly. Still, it may be good to have a lab notebook, e.g. a word file or similar, where you record what you are doing and what your results are. Keep the lab notebook with your project!
