This is a structure of an example project. 

* Navigate to the subfolders to see comments there
* You can download the whole folder structure and start your thesis / project from there
* I STRONGLY recommend to put the whole folder under version control --> See lab about version control!!!