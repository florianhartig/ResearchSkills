Find some simulated data in the mydata.txt file.
For your own data generation please keep in mind:

* write your variables in columns
	* every row is one observation
* assign sensible/ recognizable variable names
	* especially helpful when working in a group
