Here we have some example data. 

For your own data, keep in mind:

* one variable one column
	* every row is one observation

* assign sensible/ recognizable variable names
	* especially helpful when working in a group
