This is a structure of an example project. 

* Navigate to the subfolders to see comments there
* See comments one folder up